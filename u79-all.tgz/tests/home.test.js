import test from 'node:test';
import assert from 'node:assert/strict';
import { settleStep, chooseFood } from '../behavior_pack/scripts/core/settle.js';
import { keepClear, inTheWay, blueprint, furnishings } from '../behavior_pack/scripts/core/house.js';

const k = (p) => `${p.x},${p.y},${p.z}`;

for (const layout of ['chests', 'cabin']) {
  test(`house (${layout}): the cells kept clear are the rooms, doorways and doorstep, never a wall`, () => {
    const o = { x: 10, y: 64, z: -5, layout };
    for (const dir of ['north', 'east', 'south', 'west']) {
      const cells = keepClear(o, dir), walls = new Set(blueprint(o, dir).map(k));
      const fur = furnishings(o, dir);
      const byKey = new Map(cells.map((c) => [k(c), c]));
      assert.ok(cells.every((c) => !walls.has(k(c))), 'no wall or roof block is "in the way"');
      for (const p of [fur.stand, fur.doorstep, fur.bed.standAt, ...(fur.stands ?? [])]) assert.ok(byKey.has(k(p)) && !byKey.get(k(p)).want, `walkable ${k(p)}`);
      assert.equal(byKey.get(k(fur.door)).want, 'door');
      assert.equal(byKey.get(k(fur.table)).want, 'crafting_table');
      assert.equal(byKey.get(k(fur.furnace)).want, 'furnace');
      for (const c of fur.chests) assert.equal(byKey.get(k(c)).want, 'chest');
      assert.equal(new Set(cells.map(k)).size, cells.length, 'no cell twice');
    }
  });
}

test('house: what counts as in the way', () => {
  const room = { x: 0, y: 0, z: 0 }, table = { x: 0, y: 0, z: 0, want: 'crafting_table' }, door = { x: 0, y: 0, z: 0, want: 'door' };
  for (const id of ['cobblestone', 'oak_planks', 'dirt', 'glass', 'white_wool', 'chest', 'water', 'lava', 'sand', 'oak_fence']) assert.ok(inTheWay(room, id), id);
  for (const id of ['air', 'short_grass', 'torch', 'red_carpet', 'stone_pressure_plate', 'snow_layer', 'fire']) assert.ok(!inTheWay(room, id), id);
  assert.ok(!inTheWay(table, 'crafting_table'));
  assert.ok(inTheWay(table, 'furnace'), 'the wrong thing in our spot');
  assert.ok(!inTheWay(door, 'wooden_door') && !inTheWay(door, 'spruce_door'));
  assert.ok(inTheWay(door, 'cobblestone'));
});

test('plan: fire first, then clearing, then repairs; day or night', () => {
  const base = { tableDist: 0, furnace: null, smelt: null, sheep: false, animals: 0, bedDeferred: false, inv: {} };
  const house = { dist: 5, bed: true, furnace: true, table: true, door: true, damage: 3 };
  for (const time of [1000, 14000]) {
    assert.equal(settleStep({ ...base, time, house: { ...house, fire: 2, blocked: 4 } }).step, 'fight_fire');
    assert.equal(settleStep({ ...base, time, house: { ...house, blocked: 4 } }).step, 'clear_house');
  }
  assert.notEqual(settleStep({ ...base, time: 1000, house: { ...house, blocked: 0, fire: 0 } }).step, 'clear_house');
});

test('eating: hunger and saturation that land, least wasted', () => {
  const inv = { cooked_beef: 4, beef: 6, bread: 3, apple: 2 };
  assert.equal(chooseFood(inv, { hunger: 12 }), 'cooked_beef', 'properly hungry: the steak (8 hunger, 12.8 saturation)');
  assert.equal(chooseFood({ beef: 6, bread: 3 }, { hunger: 12 }), 'bread', 'bread beats raw beef');
  assert.equal(chooseFood(inv, { hunger: 19, saturation: 18 }), 'beef', 'full and saturated: the smallest bite (least wasted), not a steak');
  assert.equal(chooseFood(inv, { hunger: 19, saturation: 0 }), 'cooked_beef', 'hurt with no saturation: the steak\'s 12.8 is the fast healing');
  assert.equal(chooseFood({ beef: 6 }, { hunger: 12, cookingSoon: true }), null, 'raw waits while some cooks');
  assert.equal(chooseFood({ beef: 6 }, { hunger: 5, cookingSoon: true }), 'beef', 'unless starving');
  assert.equal(chooseFood({ beef: 6 }, { hunger: 12, health: 6, cookingSoon: true }), 'beef', 'or badly hurt');
  assert.equal(chooseFood({ chicken: 3 }, { hunger: 10 }), null, 'raw chicken only when starving');
  assert.equal(chooseFood({ rotten_flesh: 3 }, { hunger: 12 }), null);
  assert.equal(chooseFood({ rotten_flesh: 3 }, { hunger: 4 }), 'rotten_flesh', 'rotten flesh: starving, nothing else');
  assert.equal(chooseFood({ rotten_flesh: 3, bread: 1 }, { hunger: 4 }), 'bread');
  assert.equal(chooseFood(inv, { hunger: 20 }), null);
});

test('no sheep to be found: once it has given up looking, the rest of the list goes on', () => {
  const house = { dist: 3, damage: 0, blocked: 0, fire: 0, door: true, bed: false, table: true, furnace: true, chest: true, signs: true, lit: true, litOutside: true };
  const base = { tableDist: 0, time: 1000, furnace: { dist: 3, inHouse: true }, smelt: null, house, sheep: false, animals: 0, inv: { stone_sword: 1, stone_pickaxe: 1, torch: 8, cooked_beef: 8 } };
  assert.equal(settleStep({ ...base, bedDeferred: false }).step, 'explore', 'still looking');
  assert.equal(settleStep({ ...base, bedDeferred: true }).step, 'done', 'given up for now: on to the farm and the iron');
});

test('house round blocks it cannot break: door moved, things moved, harmless ones left', async () => {
  const { planAroundFixed, frame, keepClear: kc, blueprint: bp, furnishings: fu } = await import('../behavior_pack/scripts/core/house.js');
  const h = { x: 0, y: 64, z: 0, dir: 'north', layout: 'chests' };
  const at = frame(h, h.dir);
  // Obsidian in the doorway: the door moves along the wall; the old doorway is wall now.
  const d = { ...h, ...planAroundFixed(h, h.dir, [at(0, 2, 0)]) };
  assert.notEqual(d.doorLx, 0);
  const walls = new Set(bp(d, d.dir).map(k));
  assert.ok(walls.has(k(at(0, 2, 1))), 'the old doorway walled up');
  assert.ok(!walls.has(k(at(d.doorLx, 2, 0))) && !walls.has(k(at(d.doorLx, 2, 1))), 'the new doorway open');
  assert.equal(k(fu(d, d.dir).door), k(at(d.doorLx, 2)));
  // Obsidian on the table's spot: the table moves (the front room's full: into the chest room).
  const t = { ...h, ...planAroundFixed(h, h.dir, [at(-1, -1, 0)]) };
  const tbl = fu(t, t.dir).table;
  assert.notEqual(k(tbl), k(at(-1, -1)));
  assert.ok(!kc(t, t.dir).some((c) => k(c) === k(at(-1, -1, 0))), 'the obsidian cell is no longer "in the way"');
  // Harmless: over the furnace at head height. Nothing moves.
  const hm = { ...h, ...planAroundFixed(h, h.dir, [at(-1, 0, 1)]) };
  assert.equal(hm.doorLx, 0);
  assert.deepEqual(hm.moved, {});
  // The bed's head spot taken: the bed moves to two free cells with a free one beside.
  const b = { ...h, ...planAroundFixed(h, h.dir, [at(1, 0, 0)]) };
  const bed = fu(b, b.dir).bed;
  assert.ok(b.moved.bed && (b.moved.bedNone || (k(bed.head) !== k(at(1, 0)) && k(bed.foot) !== k(at(1, 0)))));
});

test('canBreak: obsidian only with a diamond pickaxe, bedrock never', async () => {
  const { canBreak } = await import('../behavior_pack/scripts/core/costs.js');
  assert.equal(canBreak('obsidian', { iron_pickaxe: 1 }), false);
  assert.equal(canBreak('obsidian', { diamond_pickaxe: 1 }), true);
  assert.equal(canBreak('bedrock', { netherite_pickaxe: 1 }), false);
  assert.equal(canBreak('cobblestone', {}), true);
});
